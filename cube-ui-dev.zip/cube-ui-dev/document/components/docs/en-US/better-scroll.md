## better-scroll module

This module exports a default function called `BetterScroll`,  for more information about better-scroll, please refer to [better-scroll lib](https://github.com/ustbhuangyi/better-scroll).

### Links

About better-scroll:

- [Home](https://ustbhuangyi.github.io/better-scroll/#/)

- [Example](https://ustbhuangyi.github.io/better-scroll/#/examples/en)
