## better-scroll 模块

该模块默认暴露出一个 `BetterScroll` 函数对象，这个对象直接从依赖库 [better-scroll](https://github.com/ustbhuangyi/better-scroll) 获得。

### 链接

关于 better-scroll 详细的文档以及示例，请参考：

- [官方文档](https://ustbhuangyi.github.io/better-scroll/#/zh)

- [官方示例](https://ustbhuangyi.github.io/better-scroll/#/examples/zh)
