import RecycleList from '../../components/recycle-list/recycle-list.vue'

RecycleList.install = function(Vue) {
  Vue.component(RecycleList.name, RecycleList)
}

export default RecycleList
